package com.techelevator.model;

import java.math.BigDecimal;

public class Budget {
    private BigDecimal savings; //How much money I have
    private BigDecimal spending; // How much I want to spend
    private BigDecimal weeklyBudget; //How much I have to use this week
    private BigDecimal savingGoals; // How much I want to save this month

    public BigDecimal getSavings() {
        return savings;
    }

    public void setSavings(BigDecimal savings) {
        this.savings = savings;
    }

    public BigDecimal getSpending() {
        return spending;
    }

    public void setSpending(BigDecimal spending) {
        this.spending = spending;
    }

    public BigDecimal getWeeklyBudget() {
        return weeklyBudget;
    }

    public void setWeeklyBudget(BigDecimal weeklyBudget) {
        this.weeklyBudget = weeklyBudget;
    }

    public BigDecimal getSavingGoals() {
        return savingGoals;
    }

    public void setSavingGoals(BigDecimal savingGoals) {
        this.savingGoals = savingGoals;
    }

    public Budget(BigDecimal savings, BigDecimal spending, BigDecimal weeklyBudget, BigDecimal savingGoals) {
        this.savings = savings;
        this.spending = spending;
        this.weeklyBudget = weeklyBudget;
        this.savingGoals = savingGoals;


    }
}
