package com.techelevator.dao;

import com.techelevator.model.Budget;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class JdbcBudgetDao implements BudgetDao{
    private JdbcTemplate jdbcTemplate;

    public JdbcBudgetDao(JdbcTemplate jdbcTemplate){this.jdbcTemplate = jdbcTemplate;}

    RestTemplate restTemplate = new RestTemplate();

    @Override
    public Budget getSavings() {
        return null;
    }
}
