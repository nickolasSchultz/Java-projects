package com.techelevator.dao;

import com.techelevator.model.Budget;

public interface BudgetDao {
        Budget getSavings();

}
