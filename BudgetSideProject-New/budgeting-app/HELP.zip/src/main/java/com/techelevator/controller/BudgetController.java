package com.techelevator.controller;


import com.techelevator.dao.BudgetDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

@RestController

public class BudgetController {
@Autowired
BudgetDao budgetDao;

}
